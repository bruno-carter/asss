import { createFileRoute } from "@tanstack/react-router";
import { Leaf, Lightbulb, ShieldCheck, Handshake } from "lucide-react";
import { useLang } from "@/lib/i18n";
import { CertRow, Container, QuoteCTA, SectionHeading } from "@/components/site/Sections";
import c1 from "@/assets/company/1.jpg";
import c2 from "@/assets/company/2.jpg";
import c3 from "@/assets/company/3.jpg";
import c4 from "@/assets/company/4.jpg";

const title = "About RUIDIE Footwear — 15 Years of Women's Shoe Manufacturing";
const description =
  "Founded in 2010 in China's footwear capital: 5,000 m² factory, 200+ skilled staff, 1M+ pairs per year and ISO 9001/14001, BSCI, SGS, CE and REACH certifications.";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: AboutPage,
});

const gallery = [c1, c2, c3, c4];
const valueIcons = [ShieldCheck, Leaf, Lightbulb, Handshake];

function AboutPage() {
  const { t } = useLang();

  return (
    <>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-card to-background" />
          <div className="bloom-accent absolute -top-24 right-1/4 h-[420px] w-[420px]" />
        </div>
        <Container className="pb-12 pt-14 lg:pt-20">
          <div className="grid items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-6">
              <SectionHeading eyebrow={t.factory.eyebrow} title={t.factory.title} className="max-w-[40ch]" />
              <p className="mt-5 max-w-[52ch] text-pretty text-base leading-relaxed text-muted-foreground">
                {t.factory.body}
              </p>
              <dl className="mt-7 grid grid-cols-2 gap-x-8 gap-y-5">
                {t.factory.facts.map((f) => (
                  <div key={f.label}>
                    <dt className="eyebrow-muted">{f.label}</dt>
                    <dd className="mt-1 font-display text-lg font-semibold">{f.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="lg:col-span-6">
              <div className="glass-strong rounded-3xl p-3">
                <div className="aspect-[4/3] overflow-hidden rounded-2xl ring-1 ring-hairline">
                  <img src={c2} alt={t.factory.gallery[1]?.title} className="size-full object-cover" fetchPriority="high" />
                </div>
                <div className="grid grid-cols-2 gap-px p-2 sm:grid-cols-4">
                  {t.hero.stats.map((s) => (
                    <div key={s.label} className="p-3">
                      <p className="font-display text-2xl font-semibold tracking-tight">{s.value}</p>
                      <p className="mt-0.5 text-[11px] font-medium text-muted-foreground">{s.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <CertRow />

      <section className="border-b border-border/70 bg-card/40 backdrop-blur">
        <Container className="py-16 lg:py-24">
          <SectionHeading eyebrow={t.values.eyebrow} title={t.values.title} />
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {t.values.items.map((v, i) => {
              const Icon = valueIcons[i] ?? ShieldCheck;
              return (
                <div key={v.title} className="glass rounded-2xl p-5">
                  <div className="grid size-10 place-items-center rounded-xl bg-brand/10 text-brand">
                    <Icon className="size-5" />
                  </div>
                  <h3 className="mt-4 font-display text-base font-semibold tracking-tight">{v.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{v.body}</p>
                </div>
              );
            })}
          </div>
        </Container>
      </section>

      <section>
        <Container className="py-16 lg:py-24">
          <SectionHeading eyebrow={t.nav.about} title={t.factory.gallery[0]?.title ?? ""} className="sr-only" />
          <div className="grid gap-4 sm:grid-cols-2">
            {t.factory.gallery.map((g, i) => (
              <figure key={g.title} className="glass overflow-hidden rounded-2xl p-3">
                <div className="aspect-[4/3] overflow-hidden rounded-xl ring-1 ring-hairline">
                  <img src={gallery[i]} alt={g.title} loading="lazy" className="size-full object-cover" />
                </div>
                <figcaption className="px-2 pb-2 pt-4">
                  <p className="font-display text-base font-semibold tracking-tight">{g.title}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{g.body}</p>
                </figcaption>
              </figure>
            ))}
          </div>
        </Container>
      </section>

      <QuoteCTA />
    </>
  );
}
