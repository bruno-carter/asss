import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { ArrowRight, Check, Clock, Mail, MapPin, Phone } from "lucide-react";
import { useLang } from "@/lib/i18n";
import { categories, type CategoryId } from "@/lib/products";
import { Container, SectionHeading } from "@/components/site/Sections";

const validCats: CategoryId[] = ["heels", "flats", "sneakers", "sandals", "boots"];

const title = "Contact & Get a Quote — RUIDIE Footwear OEM/ODM";
const description =
  "Tell us about your women's footwear project and receive a professional quote within 48 hours. MOQ 500 pairs, samples in 7–15 days, factory visits welcome.";

export const Route = createFileRoute("/contact")({
  validateSearch: (search: Record<string, unknown>): { category?: CategoryId } => {
    const c = search["category"];
    return validCats.includes(c as CategoryId) ? { category: c as CategoryId } : {};
  },
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: ContactPage,
});

const fieldClass =
  "w-full rounded-xl bg-card px-3.5 py-2.5 text-sm text-foreground ring-1 ring-hairline placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-ring";

function ContactPage() {
  const { t, lang } = useLang();
  const { category } = Route.useSearch();
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const f = t.contact.form;

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus("sending");
    // Inquiries are held locally until a backend is connected.
    window.setTimeout(() => setStatus("sent"), 600);
  };

  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-b from-card via-background to-background" />
        <div className="bloom-brand absolute -top-24 left-1/4 h-[480px] w-[480px]" />
        <div className="bloom-accent absolute right-0 top-40 h-[360px] w-[360px]" />
      </div>

      <Container className="py-14 lg:py-20">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <SectionHeading eyebrow={t.contact.eyebrow} title={t.contact.title} body={t.contact.body} />

            <div className="glass mt-8 rounded-2xl p-5">
              <p className="eyebrow-muted">{t.contact.details.title}</p>
              <ul className="mt-4 space-y-3 text-sm">
                <li className="flex items-center gap-3">
                  <Mail className="size-4 text-brand" />
                  <a href={`mailto:${t.contact.details.email}`} className="font-medium hover:text-brand">
                    {t.contact.details.email}
                  </a>
                </li>
                <li className="flex items-center gap-3">
                  <Phone className="size-4 text-brand" />
                  <span className="font-medium">{t.contact.details.phone}</span>
                </li>
                <li className="flex items-center gap-3">
                  <MapPin className="size-4 text-brand" />
                  <span className="text-foreground/75">{t.contact.details.address}</span>
                </li>
                <li className="flex items-center gap-3">
                  <Clock className="size-4 text-brand" />
                  <span className="text-foreground/75">{t.contact.details.hours}</span>
                </li>
              </ul>
            </div>

            <div className="glass mt-4 rounded-2xl p-5">
              <p className="font-display text-base font-semibold tracking-tight">{t.contact.visit.title}</p>
              <p className="mt-1 text-sm text-muted-foreground">{t.contact.visit.body}</p>
            </div>

            <div className="mt-6 grid grid-cols-3 gap-4">
              {t.hero.terms.map((term) => (
                <div key={term.label}>
                  <p className="eyebrow-muted">{term.label}</p>
                  <p className="mt-1 text-sm font-semibold">{term.value}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="glass-strong rounded-3xl p-6 lg:p-8">
              {status === "sent" ? (
                <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
                  <div className="grid size-12 place-items-center rounded-full bg-brand/10 text-brand">
                    <Check className="size-6" />
                  </div>
                  <h2 className="mt-5 font-display text-2xl font-semibold tracking-tight">{f.successTitle}</h2>
                  <p className="mt-2 max-w-[40ch] text-pretty text-sm text-muted-foreground">{f.successBody}</p>
                  <button
                    type="button"
                    onClick={() => setStatus("idle")}
                    className="mt-6 text-sm font-semibold text-brand hover:underline"
                  >
                    {f.another}
                  </button>
                </div>
              ) : (
                <form onSubmit={onSubmit} className="grid gap-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label={f.name}>
                      <input name="name" required className={fieldClass} autoComplete="name" />
                    </Field>
                    <Field label={f.company}>
                      <input name="company" required className={fieldClass} autoComplete="organization" />
                    </Field>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label={f.email}>
                      <input name="email" type="email" required className={fieldClass} autoComplete="email" />
                    </Field>
                    <Field label={f.country}>
                      <input name="country" className={fieldClass} autoComplete="country-name" />
                    </Field>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label={f.category}>
                      <select name="category" defaultValue={category ?? ""} className={fieldClass}>
                        <option value="">—</option>
                        {categories.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name[lang]}
                          </option>
                        ))}
                      </select>
                    </Field>
                    <Field label={f.quantity}>
                      <input name="quantity" type="number" min={1} step={100} placeholder="500" className={fieldClass} />
                    </Field>
                  </div>
                  <Field label={f.message}>
                    <textarea
                      name="message"
                      rows={5}
                      required
                      placeholder={f.messagePlaceholder}
                      className={`${fieldClass} resize-y`}
                    />
                  </Field>
                  <button
                    type="submit"
                    disabled={status === "sending"}
                    className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-ink py-3 pl-5 pr-6 text-sm font-semibold text-ink-foreground ring-1 ring-inset ring-ink/40 transition hover:brightness-110 disabled:opacity-60"
                  >
                    {status === "sending" ? f.sending : f.submit}
                    <ArrowRight className="size-4 text-accent" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="eyebrow-muted">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}
