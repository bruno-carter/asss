import { createFileRoute } from "@tanstack/react-router";
import { useLang } from "@/lib/i18n";
import { CertRow, Container, QuoteCTA, SectionHeading } from "@/components/site/Sections";
import c1 from "@/assets/company/1.jpg";
import c3 from "@/assets/company/3.jpg";
import c4 from "@/assets/company/4.jpg";

const title = "Craftsmanship — 8-Step Footwear Production & QC Process | RUIDIE";
const description =
  "From design and material sourcing to lasting, 8-point inspection and global shipping: how RUIDIE controls every step of women's footwear production with a 99.5% pass rate.";

export const Route = createFileRoute("/craftsmanship")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: CraftsmanshipPage,
});

function CraftsmanshipPage() {
  const { t } = useLang();
  const photos = [c1, c3, c4];

  return (
    <>
      <section className="relative overflow-hidden border-b border-border/70">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-card to-background" />
          <div className="bloom-brand absolute -top-24 left-1/3 h-[480px] w-[480px]" />
        </div>
        <Container className="pb-12 pt-14 lg:pt-20">
          <div className="grid items-end gap-10 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <SectionHeading eyebrow={t.process.eyebrow} title={t.process.title} body={t.process.body} />
            </div>
            <div className="lg:col-span-5">
              <div className="glass-strong grid grid-cols-3 gap-4 rounded-2xl p-5">
                {t.hero.terms.map((term) => (
                  <div key={term.label}>
                    <p className="eyebrow-muted">{term.label}</p>
                    <p className="mt-1 font-display text-lg font-semibold">{term.value}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Container>
      </section>

      <Container className="py-16 lg:py-24">
        <ol className="relative grid gap-4 lg:grid-cols-2">
          {t.process.steps.map((step, i) => (
            <li key={step.title} className="glass flex gap-5 rounded-2xl p-6">
              <span
                className={`font-display text-3xl font-semibold leading-none ${i === 7 ? "text-accent" : "text-brand"}`}
              >
                {String(i + 1).padStart(2, "0")}
              </span>
              <div>
                <h3 className="font-display text-lg font-semibold tracking-tight">{step.title}</h3>
                <p className="mt-1.5 max-w-[52ch] text-pretty text-sm text-muted-foreground">{step.body}</p>
              </div>
            </li>
          ))}
        </ol>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {photos.map((src, i) => {
            const g = t.factory.gallery[[0, 2, 3][i] ?? 0];
            return (
              <figure key={src} className="glass overflow-hidden rounded-2xl p-3">
                <div className="aspect-[4/3] overflow-hidden rounded-xl ring-1 ring-hairline">
                  <img src={src} alt={g?.title} loading="lazy" className="size-full object-cover" />
                </div>
                <figcaption className="px-2 pb-1 pt-3 text-sm text-muted-foreground">{g?.body}</figcaption>
              </figure>
            );
          })}
        </div>
      </Container>

      <CertRow />
      <QuoteCTA />
    </>
  );
}
