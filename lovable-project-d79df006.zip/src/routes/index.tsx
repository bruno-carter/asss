import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Plus } from "lucide-react";
import { useLang } from "@/lib/i18n";
import { categories, featuredProducts } from "@/lib/products";
import {
  CertRow,
  Container,
  GhostLink,
  PrimaryLink,
  ProductCard,
  QuoteCTA,
  SectionHeading,
} from "@/components/site/Sections";
import factoryHero from "@/assets/company/1.jpg";
import factoryWide from "@/assets/company/2.jpg";

const title = "RUIDIE Footwear — Women's Shoe OEM/ODM Manufacturer in China";
const description =
  "Precision women's footwear manufacturing for global brands: 5,000 m² factory, 1M+ pairs/year, 8-step QC, ISO/BSCI certified, quotes within 48 hours.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: Index,
});

function Index() {
  const { t, lang } = useLang();

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-card via-background to-background" />
          <div className="bloom-brand absolute -top-24 left-1/4 h-[520px] w-[520px]" />
          <div className="bloom-accent absolute right-0 top-20 h-[420px] w-[420px]" />
        </div>

        <Container className="pb-12 pt-16 lg:pt-24">
          <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-12">
            <div className="lg:col-span-6">
              <div className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold text-foreground/70 ring-1 ring-hairline backdrop-blur">
                <span className="size-1.5 rounded-full bg-accent" />
                {t.hero.badge}
              </div>

              <h1 className="mt-6 max-w-[20ch] text-balance font-display text-4xl font-semibold leading-[1.02] tracking-tight sm:text-5xl lg:text-6xl">
                {t.hero.title}
              </h1>

              <p className="mt-6 max-w-[48ch] text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
                {t.hero.body}
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <PrimaryLink to="/contact">{t.hero.cta}</PrimaryLink>
                <GhostLink to="/craftsmanship">{t.hero.secondary}</GhostLink>
              </div>

              <div className="glass mt-10 max-w-md rounded-2xl p-5">
                <p className="text-pretty text-sm leading-relaxed text-foreground/75">{t.hero.quote}</p>
                <div className="mt-4 flex items-center gap-3">
                  <div className="grid size-9 place-items-center rounded-full bg-foreground/10 text-xs font-semibold text-foreground/60">
                    JW
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{t.hero.quoteName}</p>
                    <p className="text-xs text-muted-foreground">{t.hero.quoteRole}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="glass-strong rounded-3xl p-6 lg:p-8">
                <div className="grid grid-cols-2 gap-px overflow-hidden rounded-xl bg-hairline ring-1 ring-hairline">
                  {t.hero.stats.map((s) => (
                    <div key={s.label} className="bg-card/40 p-5">
                      <p className="font-display text-3xl font-semibold tracking-tight">{s.value}</p>
                      <p className="mt-1 text-xs font-medium text-muted-foreground">{s.label}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-5 grid grid-cols-3 gap-4">
                  {t.hero.terms.map((term) => (
                    <div key={term.label}>
                      <p className="eyebrow-muted">{term.label}</p>
                      <p className="mt-1 text-sm font-semibold">{term.value}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 aspect-[16/9] overflow-hidden rounded-2xl ring-1 ring-hairline">
                <img src={factoryHero} alt={t.hero.imageAlt} className="size-full object-cover" fetchPriority="high" />
              </div>
            </div>
          </div>
        </Container>
      </section>

      <CertRow />

      {/* Product categories */}
      <section id="products">
        <Container className="py-16 lg:py-24">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <SectionHeading eyebrow={t.products.eyebrow} title={t.products.title} className="max-w-[40ch]" />
            <p className="max-w-[36ch] text-pretty text-sm text-muted-foreground">{t.products.body}</p>
          </div>

          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-6">
            {categories.map((cat, i) => (
              <Link
                key={cat.id}
                to="/products"
                search={{ cat: cat.id }}
                className={`glass group flex min-h-[220px] flex-col rounded-2xl p-5 transition hover:bg-glass-strong ${
                  i < 3 ? "lg:col-span-2" : "lg:col-span-3"
                }`}
              >
                <div
                  className={`overflow-hidden rounded-xl bg-card ring-1 ring-hairline ${i < 3 ? "aspect-[16/10]" : "aspect-[16/9]"}`}
                >
                  <img
                    src={cat.cover}
                    alt={cat.name[lang]}
                    loading="lazy"
                    className="size-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
                  />
                </div>
                <div className="mt-4 flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-display text-lg font-semibold tracking-tight">{cat.name[lang]}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{cat.body[lang]}</p>
                  </div>
                  <ArrowRight className="mt-1 size-4 shrink-0 text-foreground/30 transition group-hover:translate-x-1 group-hover:text-brand" />
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {featuredProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
          <div className="mt-8 flex justify-center">
            <GhostLink to="/products">{t.products.viewAll}</GhostLink>
          </div>
        </Container>
      </section>

      {/* Process */}
      <section id="process" className="border-y border-border/70 bg-card/40 backdrop-blur">
        <Container className="py-16 lg:py-24">
          <SectionHeading eyebrow={t.process.eyebrow} title={t.process.title} />
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {t.process.steps.map((step, i) => (
              <div key={step.title} className="glass rounded-2xl p-5">
                <span className={`font-display text-2xl font-semibold ${i === 7 ? "text-accent" : "text-brand"}`}>
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-3 font-display text-base font-medium tracking-tight">{step.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{step.body}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      {/* Factory */}
      <section id="about">
        <Container className="py-16 lg:py-24">
          <div className="grid items-center gap-10 lg:grid-cols-12">
            <div className="lg:col-span-6">
              <div className="aspect-[4/3] overflow-hidden rounded-2xl ring-1 ring-hairline">
                <img src={factoryWide} alt={t.factory.gallery[0]?.title} loading="lazy" className="size-full object-cover" />
              </div>
            </div>
            <div className="lg:col-span-6">
              <SectionHeading eyebrow={t.factory.eyebrow} title={t.factory.title} className="max-w-[40ch]" />
              <p className="mt-5 max-w-[52ch] text-pretty text-base leading-relaxed text-muted-foreground">
                {t.factory.body}
              </p>
              <dl className="mt-7 grid grid-cols-2 gap-x-8 gap-y-5">
                {t.factory.facts.map((f) => (
                  <div key={f.label}>
                    <dt className="eyebrow-muted">{f.label}</dt>
                    <dd className="mt-1 font-display text-lg font-semibold">{f.value}</dd>
                  </div>
                ))}
              </dl>
              <div className="mt-8">
                <GhostLink to="/about">{t.nav.about}</GhostLink>
              </div>
            </div>
          </div>
        </Container>
      </section>

      {/* Testimonials */}
      <section className="border-t border-border/70 bg-card/40 backdrop-blur">
        <Container className="py-16 lg:py-24">
          <SectionHeading eyebrow={t.testimonials.eyebrow} title={t.testimonials.title} className="max-w-[48ch]" />
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {t.testimonials.items.map((item) => (
              <figure key={item.name} className="glass rounded-2xl p-6">
                <blockquote className="text-pretty text-sm leading-relaxed text-foreground/75">“{item.quote}”</blockquote>
                <figcaption className="mt-5 flex items-center gap-3">
                  <div className="grid size-9 place-items-center rounded-full bg-foreground/10 text-xs font-semibold text-foreground/60">
                    {item.initials}
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{item.name}</p>
                    <p className="text-xs text-muted-foreground">{item.role}</p>
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </Container>
      </section>

      {/* FAQ */}
      <section>
        <Container className="py-16 lg:py-24">
          <div className="grid gap-10 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <SectionHeading eyebrow={t.faq.eyebrow} title={t.faq.title} body={t.faq.body} />
            </div>
            <div className="lg:col-span-8">
              <div className="glass divide-y divide-border/70 rounded-2xl">
                {t.faq.items.map((item) => (
                  <details key={item.q} className="group p-5">
                    <summary className="flex cursor-pointer list-none items-start justify-between gap-4 [&::-webkit-details-marker]:hidden">
                      <h3 className="font-display text-base font-semibold tracking-tight">{item.q}</h3>
                      <Plus className="mt-0.5 size-4 shrink-0 text-foreground/30 transition group-open:rotate-45" />
                    </summary>
                    <p className="mt-2 max-w-[70ch] text-sm text-muted-foreground">{item.a}</p>
                  </details>
                ))}
              </div>
            </div>
          </div>
        </Container>
      </section>

      <QuoteCTA />
    </>
  );
}
