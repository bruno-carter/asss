import { createFileRoute, Link } from "@tanstack/react-router";
import { useLang } from "@/lib/i18n";
import { categories, products, type CategoryId } from "@/lib/products";
import { Container, ProductCard, QuoteCTA, SectionHeading } from "@/components/site/Sections";
import { cn } from "@/lib/utils";

const validCats: CategoryId[] = ["heels", "flats", "sneakers", "sandals", "boots"];

const title = "Products — Women's Heels, Flats, Sneakers, Sandals & Boots | RUIDIE Footwear";
const description =
  "Browse women's footwear styles manufactured by RUIDIE for global brands. Full OEM/ODM customization across heels, flats, sneakers, sandals and boots. MOQ 500 pairs.";

export const Route = createFileRoute("/products")({
  validateSearch: (search: Record<string, unknown>): { cat?: CategoryId } => {
    const cat = search["cat"];
    return validCats.includes(cat as CategoryId) ? { cat: cat as CategoryId } : {};
  },
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
    ],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  const { t, lang } = useLang();
  const { cat } = Route.useSearch();
  const list = cat ? products.filter((p) => p.category === cat) : products;

  return (
    <>
      <section className="relative overflow-hidden border-b border-border/70">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-card to-background" />
          <div className="bloom-brand absolute -top-24 right-1/4 h-[420px] w-[420px]" />
        </div>
        <Container className="pb-10 pt-14 lg:pt-20">
          <SectionHeading eyebrow={t.products.eyebrow} title={t.products.pageTitle} body={t.products.pageBody} />

          <div className="mt-8 flex flex-wrap gap-2">
            <FilterChip active={!cat} to={undefined} label={`${t.products.all} · ${products.length}`} />
            {categories.map((c) => (
              <FilterChip
                key={c.id}
                active={cat === c.id}
                to={c.id}
                label={`${c.name[lang]} · ${products.filter((p) => p.category === c.id).length}`}
              />
            ))}
          </div>
        </Container>
      </section>

      <Container className="py-12 lg:py-16">
        {cat && (
          <p className="mb-6 max-w-[60ch] text-pretty text-sm text-muted-foreground">
            {categories.find((c) => c.id === cat)?.body[lang]}
          </p>
        )}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {list.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </Container>

      <QuoteCTA />
    </>
  );
}

function FilterChip({ active, to, label }: { active: boolean; to: CategoryId | undefined; label: string }) {
  return (
    <Link
      to="/products"
      search={to ? { cat: to } : {}}
      className={cn(
        "rounded-full px-4 py-2 text-sm font-semibold ring-1 transition",
        active
          ? "bg-ink text-ink-foreground ring-ink"
          : "glass text-foreground/70 ring-hairline hover:text-foreground",
      )}
    >
      {label}
    </Link>
  );
}
