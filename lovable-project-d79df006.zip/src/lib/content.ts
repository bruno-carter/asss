export type Lang = "en" | "zh";

const en = {
  brand: { name: "RUIDIE", tagline: "Footwear Manufacturing" },
  nav: {
    home: "Home",
    products: "Products",
    about: "About",
    craftsmanship: "Craftsmanship",
    contact: "Contact",
    quote: "Get a Quote",
  },
  hero: {
    badge: "ISO 9001 · 14001 · BSCI · SGS · CE · REACH",
    title: "Precision women's footwear manufacturing, built for global buyers.",
    body:
      "A 5,000 m² facility producing over 1,000,000 pairs a year for 60+ markets. Eight-stage quality control, 99.5% pass rate, and quotes delivered within 48 hours.",
    cta: "Get a Quote",
    secondary: "See the 8-step process",
    quote:
      "“RUIDIE's sampling is fast and quality is consistent. We've partnered for 3 years, ordering 200,000+ pairs annually.”",
    quoteName: "James Whitfield",
    quoteRole: "Head of Sourcing, UK footwear brand",
    stats: [
      { value: "1M+", label: "Pairs produced per year" },
      { value: "60+", label: "Export markets" },
      { value: "99.5%", label: "QC pass rate" },
      { value: "5,000 m²", label: "Factory floor space" },
    ],
    terms: [
      { label: "MOQ", value: "500 / style" },
      { label: "Samples", value: "7–15 days" },
      { label: "Production", value: "30–45 days" },
    ],
    imageAlt: "RUIDIE footwear production workshop",
  },
  certs: {
    label: "Certified to",
    items: ["ISO 9001", "ISO 14001", "CE", "SGS", "BSCI", "REACH"],
  },
  products: {
    eyebrow: "Product range",
    title: "Five core categories, one production standard.",
    body:
      "Every line runs through the same eight-stage QC. Share your target specs and we'll confirm fit-for-purpose.",
    viewAll: "View all products",
    pageTitle: "Women's footwear we manufacture",
    pageBody:
      "A selection of styles produced for our partners. All categories are available for OEM/ODM customization — lasts, materials, logo and packaging.",
    all: "All",
    styles: "styles",
    inquire: "Inquire about this style",
  },
  process: {
    eyebrow: "How we build",
    title: "An eight-step process, documented end to end.",
    body: "From design to delivery, every step is strictly controlled and traceable.",
    steps: [
      { title: "Design & Development", body: "In-house designers turn sketches or samples into production-ready tech packs." },
      { title: "Material Sourcing", body: "Top-grain leather, sheepskin and microfiber under strict supply-chain control." },
      { title: "Precision Cutting", body: "Computer-aided cutting against approved patterns for accurate components." },
      { title: "Hand Stitching", body: "Experienced technicians stitch uppers with in-line checkpoints." },
      { title: "Lasting & Shaping", body: "Uppers are lasted, shaped and bonded for a consistent fit." },
      { title: "Quality Inspection", body: "8-point full inspection on every pair — 99.5%+ pass rate." },
      { title: "Packaging", body: "Custom branded boxes, labels and inserts to your specification." },
      { title: "Global Shipping", body: "Air, sea and multimodal freight to 60+ countries." },
    ],
  },
  factory: {
    eyebrow: "Factory capability",
    title: "A 5,000 m² plant, 200+ specialists, and the capacity to scale.",
    body:
      "Founded in 2010 in China's footwear capital, our facility combines in-house cutting, stitching, lasting and finishing with a dedicated QC team. From a 500-pair MOQ to full seasonal programs, capacity is planned around your order calendar.",
    facts: [
      { label: "Founded", value: "2010" },
      { label: "Team", value: "200+ staff" },
      { label: "Capacity", value: "1M+ pairs / yr" },
      { label: "Quote turnaround", value: "Within 48h" },
    ],
    gallery: [
      { title: "Production workshop", body: "Modern workshop with efficient assembly lines." },
      { title: "Cutting equipment", body: "Precision cutting for accurate material components." },
      { title: "Stitching team", body: "Professional stitching by experienced technicians." },
      { title: "QC & packaging", body: "Every pair checked before shipment." },
    ],
  },
  values: {
    eyebrow: "Why buyers choose us",
    title: "Quality, compliance and honest lead times.",
    items: [
      { title: "Quality first", body: "Every pair passes an 8-step full inspection — 99.5%+ pass rate." },
      { title: "Sustainability", body: "Eco-friendly materials and processes compliant with EU REACH and more." },
      { title: "Innovation", body: "An in-house design team tracking global trends in materials and techniques." },
      { title: "Integrity", body: "Transparent pricing and on-time delivery — long-term, trust-based partnerships." },
    ],
  },
  testimonials: {
    eyebrow: "Trusted by buyers",
    title: "What procurement teams tell us.",
    items: [
      {
        quote: "RUIDIE's sampling is fast and quality is consistent. We've partnered for 3 years, ordering 200,000+ pairs annually.",
        name: "James Whitfield",
        role: "Head of Sourcing, UK brand",
        initials: "JW",
      },
      {
        quote: "Large factory, advanced equipment and a professional QC team. On-time delivery — a highly reliable OEM partner.",
        name: "Sarah Mitchell",
        role: "Senior Buyer, US retailer",
        initials: "SM",
      },
      {
        quote: "They followed the project from design to mass production with smooth communication. The final product exceeded expectations.",
        name: "Hans Becker",
        role: "Managing Director, DE distributor",
        initials: "HB",
      },
    ],
  },
  faq: {
    eyebrow: "FAQ",
    title: "Answers for procurement teams.",
    body: "Can't find it? Send your spec sheet and we'll respond within one business day.",
    items: [
      {
        q: "What is your minimum order quantity (MOQ)?",
        a: "Standard styles: 500 pairs per style/color. Custom styles are negotiable, and small trial orders are accepted for first-time projects.",
      },
      {
        q: "How long does sampling take?",
        a: "First samples typically take 7–15 business days; revisions take 5–7 days. Complex craftsmanship or special materials may require more time. Confirmed timelines are provided in writing.",
      },
      {
        q: "Can you customize design and packaging?",
        a: "Yes. We offer full OEM/ODM customization — design from sketches or samples, custom lasts, material selection, logo and packaging box branding.",
      },
      {
        q: "What shipping options are available and how long is delivery?",
        a: "Air, sea, land and multimodal shipping are available. Mass production lead time is typically 30–45 days, depending on order volume and complexity.",
      },
    ],
  },
  cta: {
    eyebrow: "Start sourcing",
    title: "Ready to put your line on our floor?",
    body: "Send your targets and we'll return a full quote within 48 hours. No commitment required.",
    primary: "Get a Quote",
    secondary: "Book a factory visit",
  },
  contact: {
    eyebrow: "Contact",
    title: "Start your footwear project.",
    body: "Tell us about your project — category, target quantity, materials and timeline — and receive a professional quote within 48 hours.",
    form: {
      name: "Your name",
      company: "Company",
      email: "Work email",
      country: "Country / region",
      category: "Product category",
      quantity: "Target quantity (pairs)",
      message: "Project details",
      messagePlaceholder: "Styles, materials, target price, timeline, packaging requirements…",
      submit: "Request a quote",
      sending: "Sending…",
      successTitle: "Request received",
      successBody: "Thank you. A sourcing manager will reply to your email within 48 hours.",
      another: "Send another request",
    },
    details: {
      title: "Direct contact",
      email: "sales@ruidiefootwear.com",
      phone: "+86 138 0000 0000",
      address: "Footwear Industrial Zone, Wenzhou, Zhejiang, China",
      hours: "Mon–Sat, 9:00–18:00 (UTC+8)",
    },
    visit: {
      title: "Factory visits welcome",
      body: "Buyers are welcome to audit our 5,000 m² facility in person or via live video walkthrough.",
    },
  },
  footer: {
    blurb: "Women's footwear manufacturing for global brands and retailers since 2010.",
    rights: "All rights reserved.",
  },
};

export type Copy = typeof en;

const zh: Copy = {
  brand: { name: "RUIDIE 瑞蝶", tagline: "女鞋制造" },
  nav: {
    home: "首页",
    products: "产品",
    about: "关于我们",
    craftsmanship: "工艺",
    contact: "联系我们",
    quote: "获取报价",
  },
  hero: {
    badge: "ISO 9001 · 14001 · BSCI · SGS · CE · REACH",
    title: "为全球品牌买家而建的精密女鞋制造。",
    body: "5,000㎡ 现代化工厂，年产 100 万+ 双，出口 60+ 个国家。八道质检流程，99.5% 合格率，48 小时内提供报价。",
    cta: "获取报价",
    secondary: "查看 8 道工序",
    quote: "“瑞蝶打样快、品质稳定。我们已合作 3 年，年订单 20 万双以上。”",
    quoteName: "James Whitfield",
    quoteRole: "英国鞋履品牌 采购负责人",
    stats: [
      { value: "100万+", label: "年产量（双）" },
      { value: "60+", label: "出口国家与地区" },
      { value: "99.5%", label: "质检合格率" },
      { value: "5,000㎡", label: "工厂面积" },
    ],
    terms: [
      { label: "起订量", value: "500 双 / 款" },
      { label: "打样", value: "7–15 天" },
      { label: "大货", value: "30–45 天" },
    ],
    imageAlt: "瑞蝶鞋业生产车间",
  },
  certs: {
    label: "认证资质",
    items: ["ISO 9001", "ISO 14001", "CE", "SGS", "BSCI", "REACH"],
  },
  products: {
    eyebrow: "产品品类",
    title: "五大核心品类，同一生产标准。",
    body: "所有产品线均执行同一套八道质检流程。告诉我们您的目标规格，我们将确认可行方案。",
    viewAll: "查看全部产品",
    pageTitle: "我们制造的女鞋",
    pageBody: "以下为我们为合作伙伴生产的部分款式。所有品类均支持 OEM/ODM 定制——楦型、材料、Logo 与包装。",
    all: "全部",
    styles: "款",
    inquire: "咨询此款式",
  },
  process: {
    eyebrow: "生产流程",
    title: "八道工序，全程记录、可追溯。",
    body: "从设计到交付，每一步严格把控。",
    steps: [
      { title: "设计开发", body: "内部设计团队将草图或样品转化为可量产的技术包。" },
      { title: "材料采购", body: "头层牛皮、羊皮、超纤，供应链严格管控。" },
      { title: "精准裁断", body: "按已确认版型进行电脑辅助裁断，部件精准。" },
      { title: "手工缝制", body: "经验丰富的技师缝制鞋面，线上设置检查点。" },
      { title: "绷楦定型", body: "鞋面绷楦、定型与粘合，确保穿着一致。" },
      { title: "品质检验", body: "每双鞋 8 项全检——合格率 99.5% 以上。" },
      { title: "包装", body: "按您的要求定制品牌鞋盒、标签与内衬。" },
      { title: "全球发运", body: "空运、海运及多式联运，覆盖 60+ 个国家。" },
    ],
  },
  factory: {
    eyebrow: "工厂实力",
    title: "5,000㎡ 厂房、200+ 名专业人员，具备规模化产能。",
    body: "瑞蝶鞋业创立于 2010 年，位于中国鞋都，自有裁断、针车、绷楦与整饰产线，并配备专职质检团队。从 500 双起订到整季项目，产能按您的订单日历统筹安排。",
    facts: [
      { label: "创立", value: "2010 年" },
      { label: "团队", value: "200+ 人" },
      { label: "产能", value: "100万+ 双 / 年" },
      { label: "报价时效", value: "48 小时内" },
    ],
    gallery: [
      { title: "生产车间", body: "现代化车间，高效流水线。" },
      { title: "裁断设备", body: "精准裁断，部件尺寸准确。" },
      { title: "针车团队", body: "经验丰富的技师专业缝制。" },
      { title: "质检与包装", body: "出货前每双必检。" },
    ],
  },
  values: {
    eyebrow: "买家选择我们的理由",
    title: "品质、合规与可信的交期。",
    items: [
      { title: "品质为先", body: "每双鞋经过 8 道全检——合格率 99.5% 以上。" },
      { title: "可持续", body: "环保材料与工艺，符合欧盟 REACH 等法规。" },
      { title: "创新", body: "内部设计团队紧跟全球趋势，持续创新材料与工艺。" },
      { title: "诚信", body: "价格透明、准时交付——建立长期互信的合作关系。" },
    ],
  },
  testimonials: {
    eyebrow: "客户信赖",
    title: "采购团队怎么说。",
    items: [
      {
        quote: "瑞蝶打样快、品质稳定。我们已合作 3 年，年订单 20 万双以上。",
        name: "James Whitfield",
        role: "英国品牌 采购负责人",
        initials: "JW",
      },
      {
        quote: "工厂规模大、设备先进、质检团队专业，准时交货——非常可靠的 OEM 伙伴。",
        name: "Sarah Mitchell",
        role: "美国零售商 高级买手",
        initials: "SM",
      },
      {
        quote: "从设计到量产全程跟进，沟通顺畅，最终产品超出预期，强烈推荐。",
        name: "Hans Becker",
        role: "德国经销商 总经理",
        initials: "HB",
      },
    ],
  },
  faq: {
    eyebrow: "常见问题",
    title: "采购团队关心的问题。",
    body: "没找到答案？发送您的规格表，我们将在一个工作日内回复。",
    items: [
      { q: "最低起订量是多少？", a: "常规款：每款每色 500 双。定制款可协商，首次合作可接受小批量试单，欢迎联系我们了解详情。" },
      { q: "打样需要多长时间？", a: "首样通常 7–15 个工作日，修改样 5–7 天。复杂工艺或特殊材料可能需要更长时间，确认的时间表将以书面形式提供。" },
      { q: "可以定制设计和包装吗？", a: "可以。我们提供完整的 OEM/ODM 定制——根据草图或样品设计、定制楦型、材料选择、Logo 与包装盒品牌化。" },
      { q: "有哪些运输方式？交期多久？", a: "支持空运、海运、陆运及多式联运。大货生产周期通常为 30–45 天，视订单数量和复杂程度而定。" },
    ],
  },
  cta: {
    eyebrow: "开始合作",
    title: "准备好把您的产品线交给我们了吗？",
    body: "发送您的目标需求，我们将在 48 小时内提供完整报价，无需任何承诺。",
    primary: "获取报价",
    secondary: "预约参观工厂",
  },
  contact: {
    eyebrow: "联系我们",
    title: "开启您的鞋履项目。",
    body: "告诉我们您的项目——品类、目标数量、材料与时间安排——48 小时内获得专业报价。",
    form: {
      name: "您的姓名",
      company: "公司名称",
      email: "工作邮箱",
      country: "国家 / 地区",
      category: "产品品类",
      quantity: "目标数量（双）",
      message: "项目详情",
      messagePlaceholder: "款式、材料、目标价格、时间安排、包装要求……",
      submit: "提交询价",
      sending: "提交中…",
      successTitle: "已收到您的询价",
      successBody: "感谢您的信任，采购经理将在 48 小时内回复您的邮件。",
      another: "再发一条询价",
    },
    details: {
      title: "直接联系",
      email: "sales@ruidiefootwear.com",
      phone: "+86 138 0000 0000",
      address: "中国浙江省温州市 鞋业产业园",
      hours: "周一至周六 9:00–18:00（UTC+8）",
    },
    visit: {
      title: "欢迎实地考察",
      body: "欢迎买家亲临或通过视频连线实地审核我们 5,000㎡ 的生产基地。",
    },
  },
  footer: {
    blurb: "自 2010 年起，为全球品牌与零售商提供女鞋制造服务。",
    rights: "保留所有权利。",
  },
};

export const copy: Record<Lang, Copy> = { en, zh };
