import heels1 from "@/assets/products/heels/1.jpg";
import heels2 from "@/assets/products/heels/2.jpg";
import heels3 from "@/assets/products/heels/3.jpg";
import heels4 from "@/assets/products/heels/4.jpg";
import heels5 from "@/assets/products/heels/5.jpg";
import flats1 from "@/assets/products/flats/1.jpg";
import flats2 from "@/assets/products/flats/2.jpg";
import flats3 from "@/assets/products/flats/3.jpg";
import flats4 from "@/assets/products/flats/4.jpg";
import flats5 from "@/assets/products/flats/5.jpg";
import flats6 from "@/assets/products/flats/6.jpg";
import sneakers1 from "@/assets/products/sneakers/1.jpg";
import sneakers2 from "@/assets/products/sneakers/2.jpg";
import sneakers3 from "@/assets/products/sneakers/3.jpg";
import sneakers4 from "@/assets/products/sneakers/4.jpg";
import sneakers5 from "@/assets/products/sneakers/5.jpg";
import sandals1 from "@/assets/products/sandals/1.jpg";
import sandals2 from "@/assets/products/sandals/2.jpg";
import sandals3 from "@/assets/products/sandals/3.jpg";
import sandals4 from "@/assets/products/sandals/4.jpg";
import boots1 from "@/assets/products/boots/1.jpg";
import boots2 from "@/assets/products/boots/2.jpg";
import boots3 from "@/assets/products/boots/3.jpg";
import boots4 from "@/assets/products/boots/4.jpg";
import type { Lang } from "./content";

export type CategoryId = "heels" | "flats" | "sneakers" | "sandals" | "boots";

type Bilingual = Record<Lang, string>;

export type Category = {
  id: CategoryId;
  name: Bilingual;
  body: Bilingual;
  cover: string;
};

export type Product = {
  id: string;
  category: CategoryId;
  name: Bilingual;
  spec: Bilingual;
  image: string;
};

export const categories: Category[] = [
  {
    id: "heels",
    name: { en: "High Heels", zh: "高跟鞋" },
    body: { en: "Stilettos, block heels and pumps in top-grain leather.", zh: "细跟、粗跟与浅口鞋，头层牛皮工艺。" },
    cover: heels1,
  },
  {
    id: "flats",
    name: { en: "Flats", zh: "平底鞋" },
    body: { en: "Loafers, Mary Janes and ballet flats for everyday lines.", zh: "乐福鞋、玛丽珍与芭蕾平底，适合日常产品线。" },
    cover: flats1,
  },
  {
    id: "sneakers",
    name: { en: "Sneakers", zh: "运动休闲鞋" },
    body: { en: "Lightweight, breathable everyday sneakers at retail volume.", zh: "轻量透气的日常运动鞋，支持零售级批量。" },
    cover: sneakers1,
  },
  {
    id: "sandals",
    name: { en: "Sandals", zh: "凉鞋" },
    body: { en: "Strappy, slide and platform sandals for spring/summer programs.", zh: "绑带、拖鞋式与厚底凉鞋，适合春夏企划。" },
    cover: sandals1,
  },
  {
    id: "boots",
    name: { en: "Boots", zh: "靴子" },
    body: { en: "Ankle, Chelsea and knee-high boots for autumn/winter ranges.", zh: "短靴、切尔西靴与长靴，适合秋冬系列。" },
    cover: boots1,
  },
];

export const products: Product[] = [
  { id: "heels-1", category: "heels", name: { en: "Classic Pointed-Toe Stiletto", zh: "经典尖头细高跟" }, spec: { en: "Top-grain leather · 8 cm stiletto · pointed toe", zh: "头层牛皮 · 8cm 细跟 · 尖头" }, image: heels1 },
  { id: "heels-2", category: "heels", name: { en: "Slingback Kitten Heel", zh: "后空猫跟鞋" }, spec: { en: "Microfiber · 5 cm kitten heel · adjustable strap", zh: "超纤 · 5cm 猫跟 · 可调节后带" }, image: heels2 },
  { id: "heels-3", category: "heels", name: { en: "Block-Heel Pump", zh: "粗跟浅口鞋" }, spec: { en: "Sheepskin lining · 7 cm block heel", zh: "羊皮内里 · 7cm 粗跟" }, image: heels3 },
  { id: "heels-4", category: "heels", name: { en: "Ankle-Strap Sandal Heel", zh: "踝带高跟凉鞋" }, spec: { en: "Patent leather · 9 cm heel · buckle strap", zh: "漆皮 · 9cm 跟 · 搭扣踝带" }, image: heels4 },
  { id: "heels-5", category: "heels", name: { en: "Square-Toe Mule Heel", zh: "方头穆勒跟鞋" }, spec: { en: "Suede · 6 cm heel · open back", zh: "反绒皮 · 6cm 跟 · 后空" }, image: heels5 },

  { id: "flats-1", category: "flats", name: { en: "Retro Block-Heel Mary Jane", zh: "复古粗跟玛丽珍" }, spec: { en: "Retro style · low block heel · elegant buckle", zh: "复古风格 · 低粗跟 · 精致搭扣" }, image: flats1 },
  { id: "flats-2", category: "flats", name: { en: "Penny Loafer", zh: "便士乐福鞋" }, spec: { en: "Top-grain leather · leather sole · hand-stitched", zh: "头层牛皮 · 真皮底 · 手工缝线" }, image: flats2 },
  { id: "flats-3", category: "flats", name: { en: "Ballet Flat", zh: "芭蕾平底鞋" }, spec: { en: "Soft nappa · bow detail · padded insole", zh: "软纳帕皮 · 蝴蝶结 · 软垫鞋垫" }, image: flats3 },
  { id: "flats-4", category: "flats", name: { en: "Pointed-Toe Flat", zh: "尖头平底鞋" }, spec: { en: "Microfiber · slip-on · flexible outsole", zh: "超纤 · 一脚蹬 · 柔软大底" }, image: flats4 },
  { id: "flats-5", category: "flats", name: { en: "Chunky Loafer", zh: "厚底乐福鞋" }, spec: { en: "Patent leather · lug sole · metal trim", zh: "漆皮 · 齿纹厚底 · 金属饰扣" }, image: flats5 },
  { id: "flats-6", category: "flats", name: { en: "Woven Leather Flat", zh: "编织皮革平底鞋" }, spec: { en: "Hand-woven leather · square toe", zh: "手工编织皮革 · 方头" }, image: flats6 },

  { id: "sneakers-1", category: "sneakers", name: { en: "Minimal White Sneaker", zh: "极简小白鞋" }, spec: { en: "Lightweight · breathable · all-season staple", zh: "轻量 · 透气 · 四季基础款" }, image: sneakers1 },
  { id: "sneakers-2", category: "sneakers", name: { en: "Retro Runner", zh: "复古跑鞋" }, spec: { en: "Suede & mesh · EVA midsole", zh: "反绒皮拼网布 · EVA 中底" }, image: sneakers2 },
  { id: "sneakers-3", category: "sneakers", name: { en: "Platform Court Sneaker", zh: "厚底板鞋" }, spec: { en: "Leather upper · 4 cm platform", zh: "皮革鞋面 · 4cm 厚底" }, image: sneakers3 },
  { id: "sneakers-4", category: "sneakers", name: { en: "Knit Slip-On", zh: "针织一脚蹬" }, spec: { en: "Flyknit upper · sock fit · rubber outsole", zh: "飞织鞋面 · 袜套式 · 橡胶大底" }, image: sneakers4 },
  { id: "sneakers-5", category: "sneakers", name: { en: "Canvas Low-Top", zh: "帆布低帮鞋" }, spec: { en: "Cotton canvas · vulcanized sole", zh: "棉帆布 · 硫化底" }, image: sneakers5 },

  { id: "sandals-1", category: "sandals", name: { en: "Summer Cross-Strap Sandal", zh: "夏季交叉带凉鞋" }, spec: { en: "Cool · cross straps · vacation ready", zh: "清凉 · 交叉绑带 · 度假风" }, image: sandals1 },
  { id: "sandals-2", category: "sandals", name: { en: "Leather Slide", zh: "皮革拖鞋" }, spec: { en: "Top-grain leather · molded footbed", zh: "头层牛皮 · 模压鞋床" }, image: sandals2 },
  { id: "sandals-3", category: "sandals", name: { en: "Platform Espadrille", zh: "厚底草编凉鞋" }, spec: { en: "Jute wrapped platform · ankle tie", zh: "黄麻包边厚底 · 踝部系带" }, image: sandals3 },
  { id: "sandals-4", category: "sandals", name: { en: "Strappy Heeled Sandal", zh: "细带高跟凉鞋" }, spec: { en: "Metallic leather · 7 cm heel", zh: "金属色皮革 · 7cm 跟" }, image: sandals4 },

  { id: "boots-1", category: "boots", name: { en: "Chelsea Boot", zh: "切尔西靴" }, spec: { en: "Top-grain leather · elastic gore · lug sole", zh: "头层牛皮 · 松紧侧带 · 齿纹底" }, image: boots1 },
  { id: "boots-2", category: "boots", name: { en: "Knee-High Riding Boot", zh: "长筒骑士靴" }, spec: { en: "Full leather · inside zip · 3 cm heel", zh: "全皮 · 内侧拉链 · 3cm 跟" }, image: boots2 },
  { id: "boots-3", category: "boots", name: { en: "Heeled Ankle Boot", zh: "高跟短靴" }, spec: { en: "Suede · 8 cm block heel · pointed toe", zh: "反绒皮 · 8cm 粗跟 · 尖头" }, image: boots3 },
  { id: "boots-4", category: "boots", name: { en: "Combat Boot", zh: "马丁靴" }, spec: { en: "Oiled leather · lace-up · Goodyear welt", zh: "油蜡皮 · 系带 · 固特异沿条" }, image: boots4 },
];

export const featuredProducts = ["heels-1", "flats-1", "sneakers-1", "sandals-1"]
  .map((id) => products.find((p) => p.id === id))
  .filter((p): p is Product => Boolean(p));
