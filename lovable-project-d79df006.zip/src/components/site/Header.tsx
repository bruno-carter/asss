import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import { useLang } from "@/lib/i18n";
import { cn } from "@/lib/utils";

const links = [
  { to: "/", key: "home" },
  { to: "/products", key: "products" },
  { to: "/about", key: "about" },
  { to: "/craftsmanship", key: "craftsmanship" },
  { to: "/contact", key: "contact" },
] as const;

export function Header() {
  const { t, lang, setLang } = useLang();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-card/70 backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="flex h-16 items-center justify-between gap-6">
          <Link to="/" className="flex shrink-0 items-baseline gap-2" onClick={() => setOpen(false)}>
            <span className="font-display text-lg font-semibold tracking-tight">{t.brand.name}</span>
            <span className="eyebrow-muted hidden sm:inline">{t.brand.tagline}</span>
          </Link>

          <nav className="hidden items-center gap-7 text-sm font-medium md:flex">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                className="text-foreground/60 transition-colors hover:text-brand"
                activeProps={{ className: "text-foreground" }}
                activeOptions={{ exact: l.to === "/" }}
              >
                {t.nav[l.key]}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <LangSwitch lang={lang} setLang={setLang} className="hidden sm:flex" />
            <Link
              to="/contact"
              className="inline-flex items-center rounded-full bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground ring-1 ring-inset ring-accent/40 transition hover:brightness-95"
            >
              {t.nav.quote}
            </Link>
            <button
              type="button"
              aria-label="Menu"
              className="inline-flex size-9 items-center justify-center rounded-full ring-1 ring-hairline md:hidden"
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="size-4" /> : <Menu className="size-4" />}
            </button>
          </div>
        </div>
      </div>

      {open && (
        <div className="border-t border-border/70 bg-card/90 backdrop-blur-xl md:hidden">
          <nav className="mx-auto flex max-w-7xl flex-col gap-1 px-6 py-4">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-foreground/70 hover:bg-muted"
                activeProps={{ className: "text-foreground bg-muted" }}
                activeOptions={{ exact: l.to === "/" }}
              >
                {t.nav[l.key]}
              </Link>
            ))}
            <div className="px-3 pt-3">
              <LangSwitch lang={lang} setLang={setLang} className="inline-flex" />
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}

function LangSwitch({
  lang,
  setLang,
  className,
}: {
  lang: "en" | "zh";
  setLang: (l: "en" | "zh") => void;
  className?: string;
}) {
  return (
    <div className={cn("items-center rounded-full bg-card p-1 text-xs font-semibold ring-1 ring-hairline", className)}>
      {(["en", "zh"] as const).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLang(l)}
          className={cn(
            "rounded-full px-3 py-1 transition-colors",
            lang === l ? "bg-ink text-ink-foreground" : "text-foreground/50 hover:text-foreground",
          )}
        >
          {l === "en" ? "EN" : "中文"}
        </button>
      ))}
    </div>
  );
}
