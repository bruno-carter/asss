import { Link } from "@tanstack/react-router";
import { useLang } from "@/lib/i18n";

export function Footer() {
  const { t } = useLang();
  const links = [
    { to: "/", label: t.nav.home },
    { to: "/products", label: t.nav.products },
    { to: "/about", label: t.nav.about },
    { to: "/craftsmanship", label: t.nav.craftsmanship },
    { to: "/contact", label: t.nav.contact },
  ] as const;

  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto max-w-7xl px-6 py-12 lg:px-10">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <span className="font-display text-lg font-semibold tracking-tight">{t.brand.name}</span>
            <p className="mt-1 max-w-[40ch] text-pretty text-sm text-ink-foreground/55">{t.footer.blurb}</p>
          </div>
          <nav className="flex flex-wrap gap-x-7 gap-y-2 text-sm font-medium text-ink-foreground/70">
            {links.map((l) => (
              <Link key={l.to} to={l.to} className="transition-colors hover:text-ink-foreground">
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-ink-foreground/10 pt-6 text-xs text-ink-foreground/45 sm:flex-row">
          <p>© {new Date().getFullYear()} RUIDIE Footwear. {t.footer.rights}</p>
          <p>ISO 9001 · 14001 · CE · SGS · BSCI · REACH</p>
        </div>
      </div>
    </footer>
  );
}
