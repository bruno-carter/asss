import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { useLang } from "@/lib/i18n";
import type { Product } from "@/lib/products";
import { categories } from "@/lib/products";
import { cn } from "@/lib/utils";

export function Container({ className, children }: { className?: string; children: React.ReactNode }) {
  return <div className={cn("mx-auto max-w-7xl px-6 lg:px-10", className)}>{children}</div>;
}

export function SectionHeading({
  eyebrow,
  title,
  body,
  className,
}: {
  eyebrow: string;
  title: string;
  body?: string;
  className?: string;
}) {
  return (
    <div className={cn("max-w-[56ch]", className)}>
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="mt-3 text-balance font-display text-3xl font-semibold tracking-tight lg:text-4xl">{title}</h2>
      {body && <p className="mt-4 text-pretty text-sm text-muted-foreground lg:text-base">{body}</p>}
    </div>
  );
}

export function PrimaryLink({
  to,
  children,
  className,
}: {
  to: "/contact" | "/products" | "/craftsmanship" | "/about";
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "inline-flex items-center gap-2 rounded-full bg-ink py-2.5 pl-4 pr-5 text-sm font-semibold text-ink-foreground ring-1 ring-inset ring-ink/40 transition hover:brightness-110",
        className,
      )}
    >
      {children}
      <ArrowRight className="size-4 text-accent" aria-hidden="true" />
    </Link>
  );
}

export function GhostLink({
  to,
  children,
  className,
}: {
  to: "/contact" | "/products" | "/craftsmanship" | "/about";
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <Link
      to={to}
      className={cn(
        "inline-flex items-center gap-2 rounded-full bg-secondary py-2.5 pl-4 pr-5 text-sm font-semibold text-foreground ring-1 ring-inset ring-foreground/10 backdrop-blur transition hover:ring-foreground/20",
        className,
      )}
    >
      {children}
    </Link>
  );
}

export function CertRow() {
  const { t } = useLang();
  return (
    <section className="border-y border-border/70 bg-card/50 backdrop-blur">
      <Container className="py-6">
        <div className="flex flex-wrap items-center gap-x-8 gap-y-3">
          <span className="eyebrow-muted">{t.certs.label}</span>
          {t.certs.items.map((c) => (
            <span key={c} className="font-display text-sm font-medium tracking-tight">
              {c}
            </span>
          ))}
        </div>
      </Container>
    </section>
  );
}

export function QuoteCTA() {
  const { t } = useLang();
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-card via-background to-card" />
        <div className="bloom-brand absolute -bottom-20 left-1/3 h-[480px] w-[480px]" />
        <div className="bloom-accent absolute right-10 top-0 h-[360px] w-[360px]" />
      </div>
      <Container className="py-16 lg:py-24">
        <div className="glass-strong rounded-3xl p-8 text-center lg:p-12">
          <p className="eyebrow">{t.cta.eyebrow}</p>
          <h2 className="mx-auto mt-4 max-w-[24ch] text-balance font-display text-3xl font-semibold tracking-tight lg:text-5xl">
            {t.cta.title}
          </h2>
          <p className="mx-auto mt-5 max-w-[48ch] text-pretty text-base leading-relaxed text-muted-foreground">
            {t.cta.body}
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <PrimaryLink to="/contact" className="py-3 pl-5 pr-6">
              {t.cta.primary}
            </PrimaryLink>
            <GhostLink to="/contact" className="py-3 pl-5 pr-6">
              {t.cta.secondary}
            </GhostLink>
          </div>
        </div>
      </Container>
    </section>
  );
}

export function ProductCard({ product }: { product: Product }) {
  const { lang, t } = useLang();
  const cat = categories.find((c) => c.id === product.category);
  return (
    <article className="glass group flex flex-col overflow-hidden rounded-2xl p-3">
      <div className="relative aspect-square overflow-hidden rounded-xl bg-card ring-1 ring-hairline">
        <img
          src={product.image}
          alt={product.name[lang]}
          loading="lazy"
          className="size-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
        />
      </div>
      <div className="flex flex-1 flex-col px-2 pb-2 pt-4">
        <span className="eyebrow-muted">{cat?.name[lang]}</span>
        <h3 className="mt-1.5 font-display text-base font-semibold tracking-tight">{product.name[lang]}</h3>
        <p className="mt-1 text-sm text-muted-foreground">{product.spec[lang]}</p>
        <Link
          to="/contact"
          search={{ category: product.category }}
          className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand transition hover:gap-2.5"
        >
          {t.products.inquire}
          <ArrowRight className="size-4" />
        </Link>
      </div>
    </article>
  );
}
